var alert = document.getElementById("status").value;

function LoginSuccess()
{
    var userVal = document.getElementById("user").value;
    var passVal = document.getElementById("pass").value;
    
    if((userVal == "admin") && (passVal == "admin"))
    {
        
    }
    else
    {
        alert("incorrect username and password!");
        location.reload();
    }

        
}

