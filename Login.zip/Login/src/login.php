<?php ob_start();
    $user = $_POST['username'];
    $pass =  $_POST['password'];
    if($user = 'admin' && $pass = 'admin')
    {
        header("Location: jdgawgdgawgdwa.html");
    }
    if(isset($_POST['submit']))
    {
        echo $_POST['username'];
        echo $_POST['password'];
    }

?>